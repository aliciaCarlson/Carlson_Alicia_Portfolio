
var weather = { "results":{
    "forecast":[
    {"code":"30", "date":"17 Oct 2014", "day":"Fri", "high":"80", "low":"62", "text":"Sunny"},
    {"code":"30", "date":"18 Oct 2014", "day":"Sat", "high":"82", "low":"63", "text":"Partly Cloudy"},
    {"code":"30", "data":"19 Oct 2014", "day":"Sun", "high":"85", "low":"65", "text":"Partly Cloudy"}
     ]}};

